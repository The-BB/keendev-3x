<?php
$title='PHPinfo on Zyxel Keenetic';
$header='PHPinfo on Zyxel Keenetic';
include('header.php');
phpinfo();
include('footer.php');
?>