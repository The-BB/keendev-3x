<?php
    $colorscheme = array(
         'image_background'   => array( 255, 255, 255, 255 ),
	 'graph_background'   => array( 255, 255, 255, 255 ),
	 'graph_background_2' => array( 255, 255, 255, 255 ),
	 'grid_stipple_1'     => array( 205, 205, 205,   0 ),
         'grid_stipple_2'     => array( 200, 200, 200,   0 ),
	 'border'             => array( 225, 225, 225, 255 ),
	 'text'               => array( 0, 0, 0, 0 ),
	 'rx'                 => array( 141, 207, 244,  50 ),
	 'rx_border'	      => array(  80,  40,  40,  90 ),
	 'tx'	              => array( 6, 105, 178,  50 ),
	 'tx_border'          => array(  60,  60,  60,  90 )
     );
?>
