<?php
$output = shell_exec('/opt/etc/quickscript.sh');
echo "<pre>$output</pre>";
echo "<br>";
echo '<a href="../qsadmin.php">Go back</a>';
?>
